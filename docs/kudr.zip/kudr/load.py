import concurrent.futures


def floating_load_order1(number_tasks: int, database_path: Union[str, Path], sample_database: Union[str, Path], sample_size: int = None):
    """
    Multi-user load simulation. Evaluates kuzudb load handling with
    multiple users concurrently attempting to access the database with heavy
    query loads

    Leverages all three order 1 floating type queries
    """
    if number_workers is None:
        number_tasks = min(number_tasks, 16)

    with concurrent.futures.ProcessPoolExecutor(max_workers=number_workers) as executor:

        future_to_url = {executor.submit(load_url, url, 60): url for url in URLS}
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                data = future.result()
            except Exception as exc:
                print("%r generated an exception: %s" % (url, exc))
            else:
                print("%r page is %d bytes" % (url, len(data)))


def fixed_load():
    if number_workers is None:
        number_tasks = min(number_tasks, 16)

    with concurrent.futures.ProcessPoolExecutor(max_workers=number_workers) as executor:

        future_to_url = {executor.submit(load_url, url, 60): url for url in URLS}
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                data = future.result()
            except Exception as exc:
                print("%r generated an exception: %s" % (url, exc))
            else:
                print("%r page is %d bytes" % (url, len(data)))
