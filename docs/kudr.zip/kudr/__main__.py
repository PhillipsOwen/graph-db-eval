"""
Entrypoint for kuzudb benchmarking package with the RTX-KG2 dataset
"""

import argparse
import json
import os
import sys
from pathlib import Path

from kudr.setup import setup_database
from kudr.operations import (
    multi_query_fixed,
    multi_query_floating_subject_order1,
    multi_query_floating_predicate_order1,
    multi_query_floating_object_order1,
)

# Modified from pip/__main__.py


def _command_parsing() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="kudzuroot",
        description="Command-line interface for evaluating the RTX-KG2 dataset with kuzudb as a backend",
    )
    parser.add_argument("-c", "--config", dest="config", action="store", required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-s", "--setup", dest="setup", action=argparse.BooleanOptionalAction)
    group.add_argument("-o", "--operation", dest="operation", action="store", choices=["all", "floating", "fixed"])

    commands = parser.parse_args()
    return commands


def main():
    command_namespace = _command_parsing()

    with open(command_namespace.config, "r", encoding="utf-8") as config_handle:
        configuration_mapping = json.load(config_handle)

    database_path = Path(configuration_mapping["database"]).resolve().absolute()
    node_file = Path(configuration_mapping["node_file"]).resolve().absolute()
    edge_file = Path(configuration_mapping["edge_file"]).resolve().absolute()

    if command_namespace.setup is not None:
        setup_database(database_path=database_path, edge_file=edge_file, node_file=node_file)
    elif command_namespace.operation is not None:
        if command_namespace.operation == "all":
            multi_query_fixed(database_path)
            multi_query_floating_subject_order1(database_path)
            multi_query_floating_predicate_order1(database_path)
            multi_query_floating_object_order1(database_path)
        elif command_namespace.operation == "floating":
            multi_query_floating_subject_order1(database_path)
            multi_query_floating_predicate_order1(database_path)
            multi_query_floating_object_order1(database_path)
        elif command_namespace.opeation == "fixed":
            multi_query_fixed(database_path)


if __name__ == "__main__":
    main()


# Remove '' and current working directory from the first entry
# of sys.path, if present to avoid using current directory
# in pip commands check, freeze, install, list and show,
# when invoked as python -m pip <command>
if sys.path[0] in ("", os.getcwd()):
    sys.path.pop(0)

# If we are running from a wheel, add the wheel to sys.path
# This allows the usage python pip-*.whl/pip install pip-*.whl
if __package__ == "":
    # __file__ is pip-*.whl/pip/__main__.py
    # first dirname call strips of '/__main__.py', second strips off '/pip'
    # Resulting path is the name of the wheel itself
    # Add that to sys.path so we can import pip
    path = os.path.dirname(os.path.dirname(__file__))
    sys.path.insert(0, path)

if __name__ == "__main__":
    sys.exit(main())
